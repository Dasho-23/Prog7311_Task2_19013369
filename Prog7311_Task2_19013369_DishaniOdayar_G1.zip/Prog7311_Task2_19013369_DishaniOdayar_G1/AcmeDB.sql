Create database ACME

create table Users(
UserId INT NOT NULL primary key,
UserName Varchar(50),
Pass Varchar(255),
email Varchar(255),
employee bit
);

create table Product(
ProductId INT NOT NULL primary key,
prodName Varchar(50),
Quantity int,
price int,
Category varchar(50),
Images varchar(255)
);

create table Orders(
OrderId INT NOT NULL primary key,
ProductId INT,
UserId INT NOT NULL,
orderDate varchar(20),
Quantity int,
 FOREIGN KEY (ProductId) REFERENCES Product(ProductId),
  FOREIGN KEY (UserId) REFERENCES Users(UserId)
 
);

INSERT INTO Users (UserId, UserName, Pass, email, employee)
values(001,'Admin','Password1','admin@gmail.com',1);
INSERT INTO Users (UserId, UserName, Pass, email, employee)
values(002,'Bogger','boingBoo1233','bog@gmail.com',1);
INSERT INTO Users (UserId, UserName, Pass, email, employee)
values(003,'Dobby','Dobbysocks45','sock@gmail.com',1);

INSERT INTO Product (ProductId, prodName, Quantity, price, Category,Images)
values(0001,'Colourpop',6,100,'Eyeshadow','colourpop.png');
INSERT INTO Product (ProductId, prodName, Quantity, price, Category,Images)
values(0002,'Nyx',7,85.75,'Lipstick','nyxlip.png');
INSERT INTO Product (ProductId, prodName, Quantity, price, Category,Images)
values(0003,'Mac',3,250,'Foundation','foundbottle.png');
INSERT INTO Product (ProductId, prodName, Quantity, price, Category,Images)
values(0004,'Gimmets',12,125.63,'Blush','blush.png');

INSERT INTO Orders (OrderId, ProductId, UserId, orderDate, Quantity)
values(00001,0002,003,'3jan19',1);
INSERT INTO Orders (OrderId, ProductId, UserId, orderDate, Quantity)
values(00002,0004,002,'12dec19',1);
INSERT INTO Orders (OrderId, ProductId, UserId, orderDate, Quantity)
values(00003,0001,001,'5feb20',1);