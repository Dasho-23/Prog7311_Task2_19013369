﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ACMEinc.Models
{
    public partial class Product
    {
        public Product()
        {
            Orders = new HashSet<Order>();
        }

        public int ProductId { get; set; }
        public string ProdName { get; set; }
        public int? Quantity { get; set; }
        public int? Price { get; set; }
        public string Category { get; set; }
        public string Images { get; set; }

        public virtual ICollection<Order> Orders { get; set; }
    }
}
