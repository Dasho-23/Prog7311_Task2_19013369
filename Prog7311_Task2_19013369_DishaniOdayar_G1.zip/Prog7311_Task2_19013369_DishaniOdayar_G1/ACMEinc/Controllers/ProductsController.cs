﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ACMEinc.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Data.SqlClient;

namespace ACMEinc.Controllers
{
    public class ProductsController : Controller
    {
        private readonly ACMEContext _context;
        ACMEContext db = new ACMEContext();
        public ProductsController(ACMEContext context)
        {
            _context = context;
        }

        // GET: Products
        public async Task<IActionResult> Index()
        {
            return View(await _context.Products.ToListAsync());
        }
        //shows the user a list of their previous orders
        [HttpGet]
        public IActionResult Previous()
        {
           
            
            return View(_context.Orders.ToList().Where(c => c.UserId.Equals("LogUserId")).ToList());
        }
        //ASP.NET C# MVC Shopping Cart with DB | E-commerce| GitHub Link
        //MrIndra
        //youtube:https://www.youtube.com/watch?v=OSJyta5dKsg
        //GitHub:https://github.com/MrIndra/ASP.NET_MVC5-ShoppingCart
        //search for a product function
        public ActionResult Partial(string search)

        {
            if (search == "")
            {
                ViewBag.a = "Please enter a search item in the search box..";
            }
            List<Product> pro = new List<Product>();
            using (SqlConnection conn = new SqlConnection("ACMEDB"))
            {
                conn.Open();
                string sql = @"select * from Product where ProdName like '%" + search + "%'";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Product p = new Product()
                    {
                        ProductId = (int)reader["pro_id"],
                        ProdName = (string)reader["pro_name"],
                        Price = (int)reader["pro_price"],
                      

                    };
                    pro.Add(p);
                }

                // GET: Products/Details/5
                public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var product = await _context.Products
                .FirstOrDefaultAsync(m => m.ProductId == id);
            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        // GET: Products/Create
    

        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Purchase([Bind("OrderId,ProductId,UserId,OrderDate,Quantity")] Order order)
        {
            
            //checks if the user is logged in
            if (HttpContext.Session.GetString("LoggedInUser") != null)
            {
               //adds the users order to the database
                    if (ModelState.IsValid)
                    {
                        _context.Add(order);
                        await _context.SaveChangesAsync();
                        return RedirectToAction(nameof(Index));
                    }
                    ViewData["ProductId"] = new SelectList(_context.Products, "ProductId", "ProductId", order.ProductId);
                    ViewData["UserId"] = new SelectList(_context.Users, "UserId", "UserId", order.UserId);
                    
                

               
                return View(_context.Products.ToList());
                //return View(_context.Users.ToList().Where(c => c.UserName.Equals(LogUsername)).ToList());
            }
            else
            {
                //if the user is not logged in take sthem back to login page
                TempData["LoginFirst"] = "You need to log in first";
                return RedirectToAction("Login", "Login");
            }
    
        }

        
        // POST: Products/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var product = await _context.Products.FindAsync(id);
            _context.Products.Remove(product);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ProductExists(int id)
        {
            return _context.Products.Any(e => e.ProductId == id);
        }
    }
}
