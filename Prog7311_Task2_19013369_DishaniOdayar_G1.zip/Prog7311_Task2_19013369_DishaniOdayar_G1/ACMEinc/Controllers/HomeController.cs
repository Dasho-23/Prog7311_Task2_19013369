﻿using ACMEinc.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace ACMEinc.Controllers
{
    public class HomeController : Controller
    {
        ACMEContext db = new ACMEContext();
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }
        //MVC - Chart- create Simple Chart and load data from DB- Entity Framework
        //https://howtodomssqlcsharpexcelaccess.blogspot.com/2019/05/mvc-chart-create-simple-chart-and-load.html
        //Displays a pie chart for the employee to see trends
        public ActionResult GetChartImage()
        {
            ArrayList xValue = new ArrayList();
            ArrayList yValue = new ArrayList();
            var results = db.Orders.ToList();
            results.ToList().ForEach(rs => xValue.Add(rs.Product));
            results.ToList().ForEach(rs => yValue.Add(rs.User));
            var key = new Chart(width: 300, height: 300)
                .AddTitle("Product")
                .AddSeries(chartType: "Pie",
                name: "Trend",
                xValue: xValue,
                yValues: yValue);
            return File(key.ToWebImage().GetBytes(), "image/jpeg");
        }
        //shows the user the products fro sale
        public IActionResult Index()
        {

            return RedirectToAction("Index", "Products");
        }
        //tells the user that they buy the one item 
        [HttpGet]
        public IActionResult Checkout()
        {
            HttpContext.Session.Clear();
            return View();
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
