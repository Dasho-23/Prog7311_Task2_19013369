﻿using ACMEinc.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ACMEinc.Controllers
{
    public class LoginController : Controller
    {
        ACMEContext db = new ACMEContext();
        public LoginController(ACMEContext context)
        {
            db = context;
        }
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Login(string username, string password, string email, Boolean employee)
        {
            User u = db.Users.Where(us => us.UserName.Equals(username) && us.Pass.Equals(password)).FirstOrDefault();
            //Checks if user exist
            if(u != null)
            {
                //checks if the user is an employee
                if (u.Employee == true)
                {
                    //if use is an employee should show them a pie chart with trends

                    HttpContext.Session.SetString("employee", u.UserName);
                    TempData["employee"] = u.UserName;
                    TempData["LogUserId"] = u.UserId;

                    return RedirectToAction("GetChartImage", "Home");
                }
                else
                {
                    HttpContext.Session.SetString("LoggedInUser", u.UserName);
                    TempData["LogUsername"] = u.UserName;
                    TempData["LogUserId"] = u.UserId;
                    return RedirectToAction("Index", "Products");

                }
            }
            else
            {
                //should tell the user to try again
                ViewBag.Error = "Incorrect details";
                return View();

            }
        }
        //clear sessions
        [HttpGet]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return View();
        }
    }
}
