﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ACMEinc.Models;

namespace ACMEinc.Controllers
{
    public class OrdersController : Controller
    {
        private readonly ACMEContext _context;

        public OrdersController(ACMEContext context)
        {
            _context = context;
        }
        public IActionResult Back()
        {

            return RedirectToAction("Index", "Products");
        }

        // GET: Orders
        public async Task<IActionResult> Index()
        {
            var aCMEContext = _context.Orders.Include(o => o.Product).Include(o => o.User);
            return View(await aCMEContext.ToListAsync());
        }

        // GET: Orders/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var order = await _context.Orders
                .Include(o => o.Product)
                .Include(o => o.User)
                .FirstOrDefaultAsync(m => m.OrderId == id);
            if (order == null)
            {
                return NotFound();
            }

            return View(order);
        }

      


        private bool OrderExists(int id)
        {
            return _context.Orders.Any(e => e.OrderId == id);
        }
    }
}
